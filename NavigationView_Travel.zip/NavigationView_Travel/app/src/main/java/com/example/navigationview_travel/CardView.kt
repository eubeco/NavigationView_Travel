package com.example.navigationview_travel

class CardView (var card_nombre: String , var card_imagen: Int) {
}