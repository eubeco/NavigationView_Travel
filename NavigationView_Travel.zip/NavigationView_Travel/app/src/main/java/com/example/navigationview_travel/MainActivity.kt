package com.example.navigationview_travel

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.MenuItem
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Spinner
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.widget.Toolbar
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.navigation.NavigationView

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)



        val toolbar = findViewById(R.id.toolbar) as Toolbar
        setSupportActionBar(toolbar)

        val drawerLayout = findViewById(R.id.drawer_layout) as DrawerLayout

        val toggle = ActionBarDrawerToggle(this, drawerLayout, toolbar, 0, 0)
        drawerLayout.addDrawerListener(toggle)
        toggle.syncState()






        val navView = findViewById(R.id.nav_view) as NavigationView




        navView.setNavigationItemSelectedListener(object :  NavigationView.OnNavigationItemSelectedListener {

            override fun onNavigationItemSelected(menuItem: MenuItem): Boolean {
                var fragmentTransaction = false
                var fragment: Fragment? = null

                when (menuItem.getItemId()) {
                    R.id.menu_seccion_1 -> {

                        setContentView(R.layout.seccion1)


                        val array_cards_view = ArrayList<CardView>()
                        array_cards_view.add(CardView("Card 1", R.drawable.whale))
                        array_cards_view.add(CardView("Card 2",R.drawable.whale2))
                        array_cards_view.add(CardView("Card 3", R.drawable.whale3))
                        array_cards_view.add(CardView("Card 4", R.drawable.whale4))
                        array_cards_view.add(CardView("Card 5", R.drawable.whale5))
                        array_cards_view.add(CardView("Card 6", R.drawable.whale6))
                        array_cards_view.add(CardView("Card 7", R.drawable.whale7))
                        array_cards_view.add(CardView("Card 8", R.drawable.whale8))
                        array_cards_view.add(CardView("Card 9", R.drawable.whale9))
                        array_cards_view.add(CardView("Card 10", R.drawable.whale10))

                        val recView = findViewById<RecyclerView>(R.id.idRecyclerView)
                        recView.setHasFixedSize(true)
                        val adaptador = ImagesAdapter(array_cards_view)
                        recView.adapter = adaptador
                        recView.layoutManager = GridLayoutManager(this@MainActivity, 2)

                        supportActionBar!!.title = menuItem.title
                        menuItem.setChecked(true)

                    }
                    R.id.menu_seccion_2 -> {
                        fragment = Fragment1()
                        fragmentTransaction = true
                    }
                    R.id.menu_seccion_3 -> {
                        fragment = Fragment1()
                        fragmentTransaction = true
                    }
                }
                if (fragmentTransaction) {
                    supportFragmentManager.beginTransaction().replace(R.id.content_frame, fragment!!).commit()
                    menuItem.setChecked(true)
                    supportActionBar!!.title = menuItem.title
                }
                drawerLayout.closeDrawers()
                return true
            }
        })

        fun onOptionsItemSelected(item: MenuItem): Boolean {
            val drawerLayout = findViewById(R.id.drawer_layout) as DrawerLayout
            when (item.itemId) {
                android.R.id.home -> {
                    drawerLayout.openDrawer(GravityCompat.START)
                    return true
                }
            }
            return super.onOptionsItemSelected(item)
        }






    }
}
